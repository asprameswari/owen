package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BlueprintAdapter extends RecyclerView.Adapter<BlueprintAdapter.BlueprintViewHolder> {
    private ArrayList<blueprint_item> mblueprintList;

    public static class BlueprintViewHolder extends RecyclerView.ViewHolder {

        public ImageView mImageView;
        public TextView mTextView;

        public BlueprintViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.imageView);
            mTextView = itemView.findViewById(R.id.text);
        }
    }

    public BlueprintAdapter(ArrayList<blueprint_item> blueprintList) {
        mblueprintList = blueprintList;
    }

    @NonNull
    @Override
    public BlueprintViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.blueprint_item, parent, false);
        BlueprintViewHolder bvh = new BlueprintViewHolder(view);
        return bvh;
    }

    @Override
    public void onBindViewHolder(@NonNull BlueprintViewHolder holder, int position) {
        blueprint_item currentItem = mblueprintList.get(position);

        holder.mImageView.setImageResource(currentItem.getImageResource());
        holder.mTextView.setText(currentItem.getText1());

    }

    @Override
    public int getItemCount() {
        return mblueprintList.size();
    }


}
