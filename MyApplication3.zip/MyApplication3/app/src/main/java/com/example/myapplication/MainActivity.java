package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<blueprint_item> mBlueprint;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private Button buttonInsert;
    private Button buttonRemove;
    private EditText edtInsert;
    private EditText edtRemove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createblueprint();
        buildRecyclerView();

        buttonInsert = findViewById(R.id.btn_insert);
        buttonRemove = findViewById(R.id.btn_remove);
        edtInsert = findViewById(R.id.ET_insert);
        edtRemove = findViewById(R.id.ET_remove);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = Integer.parseInt(edtInsert.getText().toString());
                insertItem(position);
            }
        });

        buttonRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = Integer.parseInt(edtRemove.getText().toString());
                removeItem(position);
            }
        });
    }

    public void insertItem(int position) {
        mBlueprint.add(position, new blueprint_item(R.drawable.diskon1, "new item inserted" + position));
        mAdapter.notifyItemInserted(position);
    }

    public void removeItem(int position) {
        mBlueprint.remove(position);
        mAdapter.notifyItemRemoved(position);
    }

    public void createblueprint() {
        ArrayList<blueprint_item> blueprint = new ArrayList<>();
        mBlueprint.add(new blueprint_item(R.drawable.lt1, "Lantai 1"));
        mBlueprint.add(new blueprint_item(R.drawable.lt2, "Lantai 2"));
        mBlueprint.add(new blueprint_item(R.drawable.lt3, "Lantai 3"));
        mBlueprint.add(new blueprint_item(R.drawable.lt4, "Lantai 4"));
        mBlueprint.add(new blueprint_item(R.drawable.lt5, "Lantai 5"));
        mBlueprint.add(new blueprint_item(R.drawable.lt6, "Lantai 6"));
        mBlueprint.add(new blueprint_item(R.drawable.lt7, "Lantai 7"));
        mBlueprint.add(new blueprint_item(R.drawable.lt8, "Lantai 8"));
    }

    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new BlueprintAdapter(mBlueprint);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }
}
