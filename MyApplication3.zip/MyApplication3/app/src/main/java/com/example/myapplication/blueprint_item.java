package com.example.myapplication;

public class blueprint_item {
    private int mImageResource;
    private String mText1;

    public blueprint_item (int imageResource, String Text1) {
        mImageResource = imageResource;
        mText1 = Text1;
    }

    public int getImageResource() {
        return mImageResource;
    }

    public String getText1() {
        return mText1;
    }
}
